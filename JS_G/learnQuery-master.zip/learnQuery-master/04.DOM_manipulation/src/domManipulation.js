var dom = function(){
  // code goes here
};