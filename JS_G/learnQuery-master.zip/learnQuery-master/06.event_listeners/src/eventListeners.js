var eventListener = (function() {
  'use strict';
  //code goes here
})();