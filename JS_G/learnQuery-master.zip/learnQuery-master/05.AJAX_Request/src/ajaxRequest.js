function ajaxReq() {
  'use strict';
  // code goes here
}