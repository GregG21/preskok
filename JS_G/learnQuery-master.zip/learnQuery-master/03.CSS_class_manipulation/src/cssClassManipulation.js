var cssClass = (function() {
  'use strict';

  // code goes here
})();