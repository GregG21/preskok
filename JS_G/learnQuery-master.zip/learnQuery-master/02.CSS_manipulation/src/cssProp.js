function cssProp() {
  'use strict';

  //code goes here
}