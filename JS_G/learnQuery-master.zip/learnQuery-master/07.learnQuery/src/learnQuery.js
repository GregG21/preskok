function learnQuery(elementsSelector) {
  //code goes here
}