var domSelector = function(selectors) {
  'use strict';

  //code goes here
};